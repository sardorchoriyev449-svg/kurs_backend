import { http } from './http';
import {
  ApiResponse,
  Attendance,
  AttendanceStatusEnum,
  ClassRoom,
  Coin,
  Course,
  Gift,
  Grade,
  Group,
  Homework,
  HomeworkStatus,
  Lesson,
  Staff,
  Topic,
  User,
  UserRole,
} from '@/types';

// ---------- Auth (/auth/sign-in, /auth/logout, /auth/me) ----------
export const authApi = {
  signIn: (login: string, password: string) =>
    http.post<ApiResponse>('/auth/sign-in', { login, password }),
  logout: () => http.post<void>('/auth/logout'),
  me: () => http.get<ApiResponse<User>>('/auth/me'),
};

// ---------- Users (/users) ----------
export interface CreateUserPayload {
  first_name: string;
  last_name: string;
  phone: string;
  data_both: string;
  password: string;
  login: string;
}

export interface UpdateUserPayload {
  first_name?: string;
  last_name?: string;
  data_both?: string;
}

export const usersApi = {
  getAll: () => http.get<ApiResponse<User[]>>('/users'),
  getOne: (id: string) => http.get<ApiResponse<User>>(`/users/${id}`),
  create: (dto: CreateUserPayload) => http.post<ApiResponse>('/users', dto),
  update: (id: string, dto: UpdateUserPayload) => http.put<ApiResponse>(`/users/update/${id}`, dto),
  updateRole: (id: string, role: UserRole) => http.put<ApiResponse>(`/users/${id}/role`, { role }),
  delete: (id: string) => http.delete<ApiResponse>(`/users/${id}`),
};

// ---------- Groups (/groups) ----------
export interface CreateGroupPayload {
  name: string;
  lesson_time: string;
  lesson_days: string[];
  teacher?: string;
  course_id: string;
}

export interface UpdateGroupPayload {
  name?: string;
  lesson_time?: string;
  lesson_days?: string[];
  teacher?: string;
  course_id?: string;
}

export const groupsApi = {
  getAll: () => http.get<ApiResponse<Group[]>>('/groups'),
  getOne: (id: string) => http.get<ApiResponse<Group>>(`/groups/${id}`),
  // Teacher yoki student o'ziga tegishli guruhlarni oladi (rolga qarab backend tanlaydi)
  getMine: () => http.get<ApiResponse<Group[]>>('/groups/mine'),
  getByTeacher: (teacherId: string) => http.get<ApiResponse<Group[]>>(`/groups/teacher/${teacherId}`),
  // Bu endpoint backend'da to'liq populate qilingan holda qaytadi (xom ObjectId emas)
  getStudents: (id: string) => http.get<ApiResponse<User[]>>(`/groups/${id}/students`),
  create: (dto: CreateGroupPayload) => http.post<ApiResponse<Group>>('/groups', dto),
  update: (id: string, dto: UpdateGroupPayload) => http.put<ApiResponse<Group>>(`/groups/${id}`, dto),
  addStudents: (id: string, students: string[]) =>
    http.post<ApiResponse<Group>>(`/groups/${id}/add-students`, { students }),
};

// ---------- Lessons (/lessons) ----------
export interface LessonPayload {
  name: string;
  description: string;
  group_id: string;
  topic_id?: string;
  date?: string;
  video_uri?: string;
  file_uri?: string;
}

export const lessonsApi = {
  getAll: () => http.get<ApiResponse<Lesson[]>>('/lessons'),
  getByGroup: (groupId: string) => http.get<ApiResponse<Lesson[]>>(`/lessons/group/${groupId}`),
  getOne: (id: string) => http.get<ApiResponse<Lesson>>(`/lessons/${id}`),
  create: (dto: LessonPayload) => http.post<ApiResponse<Lesson>>('/lessons', dto),
  update: (id: string, dto: Partial<LessonPayload>) => http.put<ApiResponse<Lesson>>(`/lessons/${id}`, dto),
  delete: (id: string) => http.delete<ApiResponse>(`/lessons/${id}`),
};

// ---------- Class rooms (/class-rooms) ----------
export interface ClassRoomPayload {
  name: string;
  size: number;
  group_id?: string[];
}

export const classroomsApi = {
  getAll: () => http.get<ApiResponse<ClassRoom[]>>('/class-rooms'),
  getOne: (id: string) => http.get<ApiResponse<ClassRoom>>(`/class-rooms/${id}`),
  create: (dto: ClassRoomPayload) => http.post<ApiResponse<ClassRoom>>('/class-rooms', dto),
  update: (id: string, dto: Partial<ClassRoomPayload>) =>
    http.put<ApiResponse<ClassRoom>>(`/class-rooms/${id}`, dto),
  assignGroup: (classroomId: string, groupId: string) =>
    http.post<ApiResponse<ClassRoom>>(`/class-rooms/${classroomId}/assign-group/${groupId}`),
  delete: (id: string) => http.delete<ApiResponse>(`/class-rooms/${id}`),
};

// ---------- Uploads (/uploads) ----------
export interface UploadedFileData {
  filename: string;
  originalName: string;
  mimetype: string;
  size: number;
  path: string;
}

export const uploadsApi = {
  uploadFile: (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return http.post<ApiResponse<UploadedFileData>>('/uploads/file', formData);
  },
};

// ---------- Course (/course) ----------
export interface CoursePayload {
  name: string;
  price: number;
  description: string;
}

export const courseApi = {
  getAll: () => http.get<ApiResponse<Course[]>>('/course'),
  getOne: (id: string) => http.get<ApiResponse<Course>>(`/course/${id}`),
  create: (dto: CoursePayload) => http.post<ApiResponse<Course>>('/course', dto),
  update: (id: string, dto: Partial<CoursePayload>) => http.put<ApiResponse<Course>>(`/course/update/${id}`, dto),
  delete: (id: string) => http.delete<ApiResponse>(`/course/${id}`),
};

// ---------- Grades (/grades) ----------
export interface GradePayload {
  student_id: string;
  lesson_id: string;
  score: number;
  comment?: string;
}

export const gradeApi = {
  getAll: () => http.get<ApiResponse<Grade[]>>('/grades'),
  getMine: () => http.get<ApiResponse<Grade[]>>('/grades/me'),
  getOne: (id: string) => http.get<ApiResponse<Grade>>(`/grades/${id}`),
  getByStudent: (studentId: string) => http.get<ApiResponse<Grade[]>>(`/grades/student/${studentId}`),
  getByLesson: (lessonId: string) => http.get<ApiResponse<Grade[]>>(`/grades/lesson/${lessonId}`),
  create: (dto: GradePayload) => http.post<ApiResponse<Grade>>('/grades', dto),
  update: (id: string, dto: Partial<Pick<GradePayload, 'score' | 'comment'>>) =>
    http.put<ApiResponse<Grade>>(`/grades/${id}`, dto),
  delete: (id: string) => http.delete<ApiResponse>(`/grades/${id}`),
};

// ---------- Attendance (/attendance) ----------
export interface AttendancePayload {
  lesson_id: string;
  student_id: string;
  status: AttendanceStatusEnum;
}

export interface BulkAttendancePayload {
  lesson_id: string;
  records: { student_id: string; status: AttendanceStatusEnum }[];
}

export const attendanceApi = {
  getAll: () => http.get<ApiResponse<Attendance[]>>('/attendance'),
  getMine: () => http.get<ApiResponse<Attendance[]>>('/attendance/me'),
  getByLesson: (lessonId: string) => http.get<ApiResponse<Attendance[]>>(`/attendance/lesson/${lessonId}`),
  getByStudent: (studentId: string) => http.get<ApiResponse<Attendance[]>>(`/attendance/student/${studentId}`),
  create: (dto: AttendancePayload) => http.post<ApiResponse<Attendance>>('/attendance', dto),
  bulkMark: (dto: BulkAttendancePayload) => http.post<ApiResponse<Attendance[]>>('/attendance/bulk', dto),
  update: (id: string, status: AttendanceStatusEnum) =>
    http.put<ApiResponse<Attendance>>(`/attendance/${id}`, { status }),
  delete: (id: string) => http.delete<ApiResponse>(`/attendance/${id}`),
};

// ---------- Coins (/coins) ----------
export interface CoinPayload {
  student_id: string;
  amount: number;
  reason: string;
}

export const coinApi = {
  getAll: () => http.get<ApiResponse<Coin[]>>('/coins'),
  getMine: () => http.get<ApiResponse<Coin[]> & { balance?: number }>('/coins/me'),
  getByStudent: (studentId: string) =>
    http.get<ApiResponse<Coin[]> & { balance?: number }>(`/coins/student/${studentId}`),
  getBalance: (studentId: string) =>
    http.get<ApiResponse<{ student_id: string; balance: number }>>(`/coins/student/${studentId}/balance`),
  create: (dto: CoinPayload) => http.post<ApiResponse<Coin>>('/coins', dto),
  delete: (id: string) => http.delete<ApiResponse>(`/coins/${id}`),
};

// ---------- Gifts (/gifts) ----------
export interface GiftPayload {
  name: string;
  price_coin: number;
  stock: number;
  description?: string;
  image?: string;
}

export const giftApi = {
  getAll: () => http.get<ApiResponse<Gift[]>>('/gifts'),
  getOne: (id: string) => http.get<ApiResponse<Gift>>(`/gifts/${id}`),
  create: (dto: GiftPayload) => http.post<ApiResponse<Gift>>('/gifts', dto),
  update: (id: string, dto: Partial<GiftPayload>) => http.put<ApiResponse<Gift>>(`/gifts/${id}`, dto),
  redeem: (giftId: string, studentId: string) =>
    http.post<ApiResponse>(`/gifts/${giftId}/redeem/${studentId}`),
  delete: (id: string) => http.delete<ApiResponse>(`/gifts/${id}`),
};

// ---------- Staff (/staff) ----------
export interface StaffPayload {
  first_name: string;
  last_name: string;
  phone: string;
  position: string;
  salary: number;
  hire_date: string;
  address?: string;
}

export const staffApi = {
  getAll: () => http.get<ApiResponse<Staff[]>>('/staff'),
  getOne: (id: string) => http.get<ApiResponse<Staff>>(`/staff/${id}`),
  create: (dto: StaffPayload) => http.post<ApiResponse<Staff>>('/staff', dto),
  update: (id: string, dto: Partial<StaffPayload>) => http.put<ApiResponse<Staff>>(`/staff/${id}`, dto),
  delete: (id: string) => http.delete<ApiResponse>(`/staff/${id}`),
};

// ---------- Homework (/homework) ----------
export interface HomeworkPayload {
  file_name: string;
  description: string;
}

export interface HomeworkReviewPayload {
  status: HomeworkStatus;
  teacher_comment?: string;
  score?: number;
}

export const homeworkApi = {
  getAll: () => http.get<ApiResponse<Homework[]>>('/homework'),
  getMine: () => http.get<ApiResponse<Homework[]>>('/homework/me'),
  getByLesson: (lessonId: string) => http.get<ApiResponse<Homework[]>>(`/homework/lesson/${lessonId}`),
  getOne: (id: string) => http.get<ApiResponse<Homework>>(`/homework/${id}`),
  create: (lessonId: string, dto: HomeworkPayload) =>
    http.post<ApiResponse<Homework>>(`/homework/lesson/${lessonId}`, dto),
  update: (lessonId: string, id: string, dto: Partial<HomeworkPayload>) =>
    http.put<ApiResponse<Homework>>(`/homework/lesson/${lessonId}/${id}`, dto),
  review: (lessonId: string, id: string, dto: HomeworkReviewPayload) =>
    http.put<ApiResponse<Homework>>(`/homework/lesson/${lessonId}/${id}`, dto),
  delete: (id: string) => http.delete<ApiResponse>(`/homework/${id}`),
};

// ---------- Topics / Mavzular (/topics) ----------
export interface TopicPayload {
  course_id: string;
  name: string;
  order?: number;
}

export const topicApi = {
  getAll: () => http.get<ApiResponse<Topic[]>>('/topics'),
  getByCourse: (courseId: string) => http.get<ApiResponse<Topic[]>>(`/topics/course/${courseId}`),
  getOne: (id: string) => http.get<ApiResponse<Topic>>(`/topics/${id}`),
  create: (dto: TopicPayload) => http.post<ApiResponse<Topic>>('/topics', dto),
  update: (id: string, dto: Partial<TopicPayload>) => http.put<ApiResponse<Topic>>(`/topics/${id}`, dto),
  delete: (id: string) => http.delete<ApiResponse>(`/topics/${id}`),
};
