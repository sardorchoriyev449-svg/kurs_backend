export enum UserRole {
  Admin = 'admin',
  SuperAdmin = 'super_admin',
  Student = 'student',
  Teacher = 'teacher',
  Viewer = 'viwer', // backend'dagi enum shunday yozilgan (xato emas, o'zi shunday)
}

export interface User {
  _id: string;
  first_name: string;
  last_name: string;
  data_both: string;
  phone: string;
  login: string;
  role: UserRole;
  createdAt?: string;
  updatedAt?: string;
}

export type UserRef = string | Partial<User>;

export interface Course {
  _id: string;
  name: string;
  price: number;
  description: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Topic {
  _id: string;
  course_id: CourseRef;
  name: string;
  order: number;
  createdAt?: string;
  updatedAt?: string;
}

export type CourseRef = string | { _id: string; name: string; price?: number };

export interface Group {
  _id: string;
  name: string;
  lesson_time: string;
  teacher: UserRef;
  students: UserRef[];
  lesson_days: string[];
  course_id: CourseRef;
  createdAt?: string;
  updatedAt?: string;
}

export type GroupRef = string | { _id: string; name: string };

export type TopicRef = string | { _id: string; name: string };

export interface Lesson {
  _id: string;
  name: string;
  description: string;
  author: UserRef;
  group_id: GroupRef;
  topic_id?: TopicRef;
  date?: string;
  video_uri?: string;
  file_uri?: string;
  createdAt?: string;
  updatedAt?: string;
}

export type LessonRef = string | { _id: string; name: string };

export interface ClassRoom {
  _id: string;
  name: string;
  size: number;
  group_id: GroupRef[];
  createdAt?: string;
  updatedAt?: string;
}

export interface Grade {
  _id: string;
  student_id: UserRef;
  lesson_id: LessonRef;
  score: number;
  comment?: string;
  graded_by: UserRef;
  createdAt?: string;
  updatedAt?: string;
}

export enum AttendanceStatusEnum {
  Keldi = 'keldi',
  Kelmadi = 'kelmadi',
  Sababli = 'sababli',
  Kechikdi = 'kechikdi',
}

export interface Attendance {
  _id: string;
  lesson_id: LessonRef;
  student_id: UserRef;
  status: AttendanceStatusEnum;
  marked_by: UserRef;
  createdAt?: string;
  updatedAt?: string;
}

export interface Coin {
  _id: string;
  student_id: UserRef;
  amount: number;
  reason: string;
  given_by?: UserRef;
  createdAt?: string;
}

export interface Gift {
  _id: string;
  name: string;
  price_coin: number;
  stock: number;
  description?: string;
  image?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Staff {
  _id: string;
  first_name: string;
  last_name: string;
  phone: string;
  position: string;
  salary: number;
  hire_date: string;
  address?: string;
  createdAt?: string;
  updatedAt?: string;
}

export enum HomeworkStatus {
  Pending = 'pending',
  Accepted = 'accepted',
  Rejected = 'rejected',
}

export interface Homework {
  _id: string;
  file_name: string;
  description: string;
  student_id: UserRef;
  lesson_id: LessonRef;
  status: HomeworkStatus;
  teacher_comment?: string;
  reviewed_by?: UserRef;
  score?: number;
  coin_awarded?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  message?: string;
  data?: T;
  length?: number;
}
