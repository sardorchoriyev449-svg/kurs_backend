'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Calendar, CheckCircle2, Clock, FileText, Video } from 'lucide-react';
import {
  attendanceApi,
  BulkAttendancePayload,
  courseApi,
  gradeApi,
  GradePayload,
  groupsApi,
  homeworkApi,
  lessonsApi,
  LessonPayload,
  topicApi,
  TopicPayload,
  uploadsApi,
} from '@/lib/api';
import { errorMessage } from '@/lib/http';
import { useToast } from '@/contexts/ToastContext';
import { Attendance, AttendanceStatusEnum, Course, Grade, Group, Homework, HomeworkStatus, Lesson, Topic, User } from '@/types';
import { ATTENDANCE_LABELS, displayCourse, formatDate, HOMEWORK_STATUS_COLORS, HOMEWORK_STATUS_LABELS, idOf, resolveUser } from '@/lib/utils';
import { API_URL } from '@/lib/constants';
import Modal from '@/components/Modal';
import { buttonDanger, buttonPrimary, buttonSecondary, inputClass, labelClass } from '@/lib/ui';

type Tab = 'info' | 'lessons' | 'homework' | 'grades' | 'attendance';

export default function TeacherGroupDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { showToast } = useToast();

  const [tab, setTab] = useState<Tab>('lessons');
  const [group, setGroup] = useState<Group | null>(null);
  const [students, setStudents] = useState<User[]>([]);
  const [courseName, setCourseName] = useState('');
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      const [groupRes, studentsRes, coursesRes] = await Promise.all([
        groupsApi.getOne(id),
        groupsApi.getStudents(id),
        courseApi.getAll(),
      ]);
      if (!groupRes.success || !groupRes.data) {
        showToast('error', groupRes.message || 'Guruh topilmadi');
        return;
      }
      setGroup(groupRes.data);
      setStudents(studentsRes.data ?? []);

      const cid = typeof groupRes.data.course_id === 'string' ? groupRes.data.course_id : groupRes.data.course_id?._id;
      const courses: Course[] = coursesRes.data ?? [];
      const found = courses.find((c) => c._id === cid);
      setCourseName(found ? found.name : displayCourse(groupRes.data.course_id));
    } catch (e) {
      showToast('error', errorMessage(e, "Ma'lumotlarni yuklab bo'lmadi"));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (loading) return <div className="text-slate-400">Yuklanmoqda...</div>;
  if (!group) return <div className="text-slate-400">Guruh topilmadi</div>;

  const TABS: { key: Tab; label: string }[] = [
    { key: 'lessons', label: 'Darslar' },
    { key: 'homework', label: 'Uy vazifalari' },
    { key: 'info', label: "O'quvchilar" },
    { key: 'grades', label: 'Baholar' },
    { key: 'attendance', label: 'Davomat' },
  ];

  return (
    <div className="space-y-6">
      <button className={buttonSecondary} onClick={() => router.push('/teacher')}>
        ← Guruhlarimga qaytish
      </button>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h1 className="text-2xl font-bold text-slate-800">{group.name}</h1>
        <div className="mt-2 flex flex-wrap gap-4 text-sm text-slate-500">
          <span className="font-medium text-indigo-600">{courseName}</span>
          <span className="flex items-center gap-1.5">
            <Clock className="h-4 w-4" /> {group.lesson_time}
          </span>
          <span className="flex items-center gap-1.5">
            <Calendar className="h-4 w-4" /> {group.lesson_days.join(', ')}
          </span>
        </div>
      </div>

      <div className="flex gap-1 border-b border-slate-200">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-4 py-2.5 text-sm font-medium transition ${
              tab === t.key ? 'border-b-2 border-indigo-600 text-indigo-700' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'info' && (
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="mb-4 text-lg font-semibold text-slate-800">O'quvchilar ({students.length})</h2>
          {students.length === 0 ? (
            <p className="text-sm text-slate-400">Bu guruhda hali o'quvchilar yo'q</p>
          ) : (
            <ul className="divide-y divide-slate-100">
              {students.map((s) => (
                <li key={s._id} className="py-2.5 text-sm text-slate-700">
                  {s.first_name} {s.last_name} <span className="text-slate-400">· {s.login}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {tab === 'lessons' && (
        <LessonsTab groupId={group._id} courseId={idOf(typeof group.course_id === 'string' ? group.course_id : group.course_id?._id)} students={students} />
      )}
      {tab === 'homework' && <HomeworkTab groupId={group._id} students={students} />}
      {tab === 'grades' && <GradesTab groupId={group._id} students={students} />}
      {tab === 'attendance' && <AttendanceTab groupId={group._id} students={students} />}
    </div>
  );
}

// ---------------- Darslar ----------------

interface LessonForm {
  mode: 'curriculum' | 'custom';
  topicId: string;
  customName: string;
  newTopicName: string;
  date: string;
  description: string;
  video_uri: string;
  file_uri: string;
}

function emptyLessonForm(): LessonForm {
  return {
    mode: 'curriculum',
    topicId: '',
    customName: '',
    newTopicName: '',
    date: new Date().toISOString().slice(0, 10),
    description: '',
    video_uri: '',
    file_uri: '',
  };
}

function LessonsTab({ groupId, courseId, students }: { groupId: string; courseId: string; students: User[] }) {
  const { showToast } = useToast();
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Lesson | null>(null);
  const [form, setForm] = useState<LessonForm>(emptyLessonForm());
  const [saving, setSaving] = useState(false);
  const [uploadingVideo, setUploadingVideo] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [creatingTopic, setCreatingTopic] = useState(false);
  const [attendance, setAttendance] = useState<Record<string, AttendanceStatusEnum>>({});

  async function loadLessons() {
    setLoading(true);
    try {
      const res = await lessonsApi.getByGroup(groupId);
      setLessons(res.data ?? []);
    } catch (e) {
      showToast('error', errorMessage(e, "Darslarni yuklab bo'lmadi"));
    } finally {
      setLoading(false);
    }
  }

  async function loadTopics() {
    if (!courseId) return;
    try {
      const res = await topicApi.getByCourse(courseId);
      setTopics(res.data ?? []);
    } catch (e) {
      showToast('error', errorMessage(e, "Mavzularni yuklab bo'lmadi"));
    }
  }

  useEffect(() => {
    loadLessons();
    loadTopics();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [groupId, courseId]);

  function openCreate() {
    setEditing(null);
    setForm(emptyLessonForm());
    const initialAttendance: Record<string, AttendanceStatusEnum> = {};
    for (const s of students) initialAttendance[s._id] = AttendanceStatusEnum.Keldi;
    setAttendance(initialAttendance);
    setModalOpen(true);
  }

  function openEdit(l: Lesson) {
    setEditing(l);
    setForm({
      mode: l.topic_id ? 'curriculum' : 'custom',
      topicId: l.topic_id ? idOf(typeof l.topic_id === 'string' ? l.topic_id : l.topic_id._id) : '',
      customName: l.topic_id ? '' : l.name,
      newTopicName: '',
      date: l.date ? l.date.slice(0, 10) : new Date().toISOString().slice(0, 10),
      description: l.description,
      video_uri: l.video_uri ?? '',
      file_uri: l.file_uri ?? '',
    });
    setModalOpen(true);
  }

  async function handleUpload(kind: 'video' | 'file', file: File) {
    const setUploading = kind === 'video' ? setUploadingVideo : setUploadingFile;
    setUploading(true);
    try {
      const res = await uploadsApi.uploadFile(file);
      if (!res.success || !res.data) {
        showToast('error', res.message || "Yuklab bo'lmadi");
        return;
      }
      setForm((f) => ({ ...f, [kind === 'video' ? 'video_uri' : 'file_uri']: res.data!.path }));
      showToast('success', 'Fayl yuklandi');
    } catch (e) {
      showToast('error', errorMessage(e, "Fayl yuklab bo'lmadi"));
    } finally {
      setUploading(false);
    }
  }

  async function handleCreateTopic() {
    if (!form.newTopicName || form.newTopicName.length < 2) {
      showToast('error', "Mavzu nomini kiriting (kamida 2 belgi)");
      return;
    }
    setCreatingTopic(true);
    try {
      const dto: TopicPayload = { course_id: courseId, name: form.newTopicName };
      const res = await topicApi.create(dto);
      if (!res.success || !res.data) {
        showToast('error', res.message || "Mavzu qo'shib bo'lmadi");
        return;
      }
      showToast('success', "Mavzu qo'shildi");
      await loadTopics();
      setForm((f) => ({ ...f, topicId: res.data!._id, newTopicName: '' }));
    } catch (e) {
      showToast('error', errorMessage(e, "Mavzu qo'shib bo'lmadi"));
    } finally {
      setCreatingTopic(false);
    }
  }

  async function handleSave() {
    const isCurriculum = form.mode === 'curriculum';
    if (isCurriculum && !form.topicId) {
      showToast('error', "Ro'yxatdan mavzu tanlang (yoki 'Boshqa'ni tanlab qo'lda yozing)");
      return;
    }
    if (!isCurriculum && !form.customName) {
      showToast('error', "Mavzu nomini yozing");
      return;
    }
    if (!form.description) {
      showToast('error', "Tavsif yozing");
      return;
    }

    const topicName = isCurriculum ? topics.find((t) => t._id === form.topicId)?.name ?? '' : form.customName;

    setSaving(true);
    try {
      const dto: LessonPayload = {
        name: topicName,
        description: form.description,
        group_id: groupId,
        topic_id: isCurriculum ? form.topicId : undefined,
        date: form.date,
        video_uri: form.video_uri || undefined,
        file_uri: form.file_uri || undefined,
      };

      if (editing) {
        const res = await lessonsApi.update(editing._id, dto);
        if (!res.success) {
          showToast('error', res.message || 'Xatolik');
          return;
        }
        showToast('success', res.message || 'Saqlandi');
      } else {
        const res = await lessonsApi.create(dto);
        if (!res.success || !res.data) {
          showToast('error', res.message || 'Xatolik');
          return;
        }
        // Davomatni shu yerning o'zida, dars bilan bir vaqtda saqlaymiz
        if (students.length > 0) {
          const bulkDto: BulkAttendancePayload = {
            lesson_id: res.data._id,
            records: students.map((s) => ({ student_id: s._id, status: attendance[s._id] ?? AttendanceStatusEnum.Kelmadi })),
          };
          await attendanceApi.bulkMark(bulkDto);
        }
        showToast('success', 'Dars va davomat saqlandi');
      }

      setModalOpen(false);
      loadLessons();
    } catch (e) {
      showToast('error', errorMessage(e, "Saqlab bo'lmadi"));
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(l: Lesson) {
    if (!confirm(`"${l.name}" darsini o'chirishga ishonchingiz komilmi?`)) return;
    try {
      const res = await lessonsApi.delete(l._id);
      if (!res.success) {
        showToast('error', res.message || 'Xatolik');
        return;
      }
      showToast('success', "O'chirildi");
      loadLessons();
    } catch (e) {
      showToast('error', errorMessage(e, "O'chirib bo'lmadi"));
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <button className={buttonPrimary} onClick={openCreate}>
          + Dars qo'shish
        </button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {loading && <p className="text-slate-400">Yuklanmoqda...</p>}
        {!loading && lessons.length === 0 && <p className="text-slate-400">Hali dars qo'shilmagan</p>}
        {lessons.map((l) => (
          <div key={l._id} className="flex flex-col rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex items-center justify-between gap-2">
              <h3 className="font-semibold text-slate-800">{l.name}</h3>
              {l.date && <span className="text-xs text-slate-400">{formatDate(l.date)}</span>}
            </div>
            <p className="mt-1 line-clamp-3 flex-1 text-sm text-slate-500">{l.description}</p>
            <div className="mt-3 flex flex-wrap gap-2 text-xs">
              {l.video_uri && (
                <a href={`${API_URL}${l.video_uri}`} target="_blank" rel="noreferrer" className="flex items-center gap-1 rounded-full bg-indigo-50 px-2.5 py-1 text-indigo-600">
                  <Video className="h-3.5 w-3.5" /> Video
                </a>
              )}
              {l.file_uri && (
                <a href={`${API_URL}${l.file_uri}`} target="_blank" rel="noreferrer" className="flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-1 text-emerald-600">
                  <FileText className="h-3.5 w-3.5" /> Fayl
                </a>
              )}
            </div>
            <div className="mt-4 flex justify-end gap-2">
              <button className={buttonSecondary} onClick={() => openEdit(l)}>
                Tahrirlash
              </button>
              <button className={buttonDanger} onClick={() => handleDelete(l)}>
                O'chirish
              </button>
            </div>
          </div>
        ))}
      </div>

      {modalOpen && (
        <Modal title={editing ? "Darsni tahrirlash" : 'Yangi dars'} onClose={() => setModalOpen(false)} widthClass="max-w-2xl">
          <div className="space-y-4">
            <div>
              <label className={labelClass}>Sana</label>
              <input type="date" className={inputClass} value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
            </div>

            <div>
              <label className={labelClass}>Mavzu</label>
              <div className="mb-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setForm({ ...form, mode: 'curriculum' })}
                  className={`rounded-full border px-3 py-1.5 text-xs font-medium transition ${
                    form.mode === 'curriculum' ? 'border-indigo-600 bg-indigo-600 text-white' : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  O'quv reja bo'yicha
                </button>
                <button
                  type="button"
                  onClick={() => setForm({ ...form, mode: 'custom' })}
                  className={`rounded-full border px-3 py-1.5 text-xs font-medium transition ${
                    form.mode === 'custom' ? 'border-indigo-600 bg-indigo-600 text-white' : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  Boshqa
                </button>
              </div>

              {form.mode === 'curriculum' ? (
                <div className="space-y-2">
                  <select className={inputClass} value={form.topicId} onChange={(e) => setForm({ ...form, topicId: e.target.value })}>
                    <option value="">Mavzulardan birini tanlang</option>
                    {topics.map((t) => (
                      <option key={t._id} value={t._id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                  <div className="flex items-center gap-2">
                    <input
                      className={inputClass}
                      placeholder="Ro'yxatda yo'q yangi mavzu nomi..."
                      value={form.newTopicName}
                      onChange={(e) => setForm({ ...form, newTopicName: e.target.value })}
                    />
                    <button type="button" className={buttonSecondary} disabled={creatingTopic} onClick={handleCreateTopic}>
                      {creatingTopic ? '...' : "+ Qo'shish"}
                    </button>
                  </div>
                </div>
              ) : (
                <input
                  className={inputClass}
                  placeholder="Mavzuni yozing..."
                  value={form.customName}
                  onChange={(e) => setForm({ ...form, customName: e.target.value })}
                />
              )}
            </div>

            <div>
              <label className={labelClass}>Tavsif</label>
              <textarea
                className={`${inputClass} min-h-[80px]`}
                placeholder="Bugungi dars haqida ma'lumot..."
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className={labelClass}>Video (ixtiyoriy)</label>
                <input type="file" accept="video/*" onChange={(e) => e.target.files?.[0] && handleUpload('video', e.target.files[0])} className="text-xs" />
                {uploadingVideo && <span className="text-xs text-slate-400">Yuklanmoqda...</span>}
                {form.video_uri && (
                  <p className="mt-1 flex items-center gap-1 truncate text-xs text-emerald-600">
                    <CheckCircle2 className="h-3.5 w-3.5 flex-shrink-0" /> {form.video_uri}
                  </p>
                )}
              </div>
              <div>
                <label className={labelClass}>Fayl (ixtiyoriy — zip ham mumkin)</label>
                <input type="file" onChange={(e) => e.target.files?.[0] && handleUpload('file', e.target.files[0])} className="text-xs" />
                {uploadingFile && <span className="text-xs text-slate-400">Yuklanmoqda...</span>}
                {form.file_uri && (
                  <p className="mt-1 flex items-center gap-1 truncate text-xs text-emerald-600">
                    <CheckCircle2 className="h-3.5 w-3.5 flex-shrink-0" /> {form.file_uri}
                  </p>
                )}
              </div>
            </div>

            {!editing && students.length > 0 && (
              <div>
                <label className={labelClass}>Davomat</label>
                <div className="max-h-56 space-y-2 overflow-y-auto rounded-lg border border-slate-100 p-3">
                  {students.map((s) => (
                    <div key={s._id} className="flex items-center justify-between gap-2">
                      <span className="text-sm text-slate-700">
                        {s.first_name} {s.last_name}
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {Object.values(AttendanceStatusEnum).map((st) => (
                          <button
                            key={st}
                            type="button"
                            onClick={() => setAttendance((prev) => ({ ...prev, [s._id]: st }))}
                            className={`rounded-full border px-2.5 py-1 text-xs font-medium transition ${
                              attendance[s._id] === st
                                ? 'border-indigo-600 bg-indigo-600 text-white'
                                : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                            }`}
                          >
                            {ATTENDANCE_LABELS[st]}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end gap-3 pt-2">
              <button className={buttonSecondary} onClick={() => setModalOpen(false)}>
                Bekor qilish
              </button>
              <button className={buttonPrimary} disabled={saving} onClick={handleSave}>
                {saving ? 'Saqlanmoqda...' : 'Saqlash'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ---------------- Uy vazifalari ----------------

function HomeworkTab({ groupId, students }: { groupId: string; students: User[] }) {
  const { showToast } = useToast();
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [lessonId, setLessonId] = useState('');
  const [homeworks, setHomeworks] = useState<Homework[]>([]);
  const [loadingLessons, setLoadingLessons] = useState(true);
  const [loadingHomeworks, setLoadingHomeworks] = useState(false);
  const [reviews, setReviews] = useState<Record<string, { comment: string; score: string }>>({});
  const [savingId, setSavingId] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      setLoadingLessons(true);
      try {
        const res = await lessonsApi.getByGroup(groupId);
        const list = res.data ?? [];
        setLessons(list);
        if (list.length > 0) setLessonId(list[0]._id);
      } catch (e) {
        showToast('error', errorMessage(e, "Darslarni yuklab bo'lmadi"));
      } finally {
        setLoadingLessons(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [groupId]);

  async function loadHomeworks() {
    if (!lessonId) return;
    setLoadingHomeworks(true);
    try {
      const res = await homeworkApi.getByLesson(lessonId);
      const list = res.data ?? [];
      setHomeworks(list);
      const nextReviews: Record<string, { comment: string; score: string }> = {};
      for (const hw of list) {
        nextReviews[hw._id] = {
          comment: hw.teacher_comment ?? '',
          score: hw.score !== undefined && hw.score !== null ? String(hw.score) : '',
        };
      }
      setReviews(nextReviews);
    } catch (e) {
      showToast('error', errorMessage(e, "Uy vazifalarini yuklab bo'lmadi"));
    } finally {
      setLoadingHomeworks(false);
    }
  }

  useEffect(() => {
    loadHomeworks();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lessonId]);

  async function handleReview(hw: Homework, status: HomeworkStatus) {
    const review = reviews[hw._id] ?? { comment: '', score: '' };

    if (status === HomeworkStatus.Accepted) {
      if (review.score === '') {
        showToast('error', "Qabul qilish uchun ball (0-100) qo'ying");
        return;
      }
      const scoreNum = Number(review.score);
      if (Number.isNaN(scoreNum) || scoreNum < 0 || scoreNum > 100) {
        showToast('error', "Ball 0 dan 100 gacha bo'lishi kerak");
        return;
      }
    }

    setSavingId(hw._id);
    try {
      const res = await homeworkApi.review(lessonId, hw._id, {
        status,
        teacher_comment: review.comment || undefined,
        score: review.score !== '' ? Number(review.score) : undefined,
      });
      if (!res.success) {
        showToast('error', res.message || 'Xatolik');
        return;
      }
      showToast('success', status === HomeworkStatus.Accepted ? 'Qabul qilindi, coin berildi' : 'Tekshirildi');
      loadHomeworks();
    } catch (e) {
      showToast('error', errorMessage(e, "Saqlab bo'lmadi"));
    } finally {
      setSavingId(null);
    }
  }

  if (loadingLessons) return <p className="text-slate-400">Yuklanmoqda...</p>;
  if (lessons.length === 0) return <p className="text-slate-400">Avval "Darslar" bo'limidan dars qo'shing.</p>;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <label className="text-sm font-medium text-slate-600">Dars:</label>
        <select className={`${inputClass} max-w-sm`} value={lessonId} onChange={(e) => setLessonId(e.target.value)}>
          {lessons.map((l) => (
            <option key={l._id} value={l._id}>
              {l.name}
            </option>
          ))}
        </select>
      </div>

      {loadingHomeworks && <p className="text-slate-400">Yuklanmoqda...</p>}
      {!loadingHomeworks && homeworks.length === 0 && (
        <p className="text-slate-400">Bu darsga hali hech kim uy vazifa topshirmagan.</p>
      )}

      <div className="space-y-3">
        {!loadingHomeworks &&
          homeworks.map((hw) => {
            const student = resolveUser(hw.student_id, students);
            return (
              <div key={hw._id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h3 className="font-semibold text-slate-800">
                    {student ? `${student.first_name} ${student.last_name}` : "Noma'lum o'quvchi"}
                  </h3>
                  <span className={`rounded-full border px-2.5 py-1 text-xs font-medium ${HOMEWORK_STATUS_COLORS[hw.status]}`}>
                    {HOMEWORK_STATUS_LABELS[hw.status]}
                  </span>
                </div>
                {hw.description && <p className="mt-1 text-sm text-slate-500">{hw.description}</p>}
                {hw.file_name && (
                  <a
                    href={`${API_URL}${hw.file_name}`}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-2 inline-flex items-center gap-1.5 text-sm text-indigo-600 hover:underline"
                  >
                    <FileText className="h-4 w-4" /> Faylni ko'rish
                  </a>
                )}
                {hw.coin_awarded && (
                  <p className="mt-2 text-xs font-medium text-purple-600">
                    Coin berildi ({hw.score} ball uchun)
                  </p>
                )}
                <div className="mt-3 grid gap-3 sm:grid-cols-[120px_1fr]">
                  <div>
                    <label className={labelClass}>Ball (0-100)</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      className={inputClass}
                      disabled={hw.coin_awarded}
                      value={reviews[hw._id]?.score ?? ''}
                      onChange={(e) =>
                        setReviews((prev) => ({ ...prev, [hw._id]: { ...prev[hw._id], score: e.target.value } }))
                      }
                    />
                  </div>
                  <div>
                    <label className={labelClass}>Izoh (ixtiyoriy)</label>
                    <input
                      className={inputClass}
                      placeholder="O'quvchiga izoh qoldiring"
                      value={reviews[hw._id]?.comment ?? ''}
                      onChange={(e) =>
                        setReviews((prev) => ({ ...prev, [hw._id]: { ...prev[hw._id], comment: e.target.value } }))
                      }
                    />
                  </div>
                </div>
                <div className="mt-3 flex justify-end gap-2">
                  <button
                    className={buttonSecondary}
                    disabled={savingId === hw._id}
                    onClick={() => handleReview(hw, HomeworkStatus.Rejected)}
                  >
                    Qaytarish
                  </button>
                  <button
                    className={buttonPrimary}
                    disabled={savingId === hw._id || hw.coin_awarded}
                    onClick={() => handleReview(hw, HomeworkStatus.Accepted)}
                  >
                    {savingId === hw._id ? 'Saqlanmoqda...' : hw.coin_awarded ? 'Qabul qilingan' : 'Qabul qilish'}
                  </button>
                </div>
              </div>
            );
          })}
      </div>
    </div>
  );
}

// ---------------- Baholar ----------------

function GradesTab({ groupId, students }: { groupId: string; students: User[] }) {
  const { showToast } = useToast();
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [lessonId, setLessonId] = useState('');
  const [loadingLessons, setLoadingLessons] = useState(true);
  const [loadingGrades, setLoadingGrades] = useState(false);
  const [rows, setRows] = useState<Record<string, { score: string; comment: string; gradeId?: string }>>({});
  const [savingId, setSavingId] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      setLoadingLessons(true);
      try {
        const res = await lessonsApi.getByGroup(groupId);
        const list = res.data ?? [];
        setLessons(list);
        if (list.length > 0) setLessonId(list[0]._id);
      } catch (e) {
        showToast('error', errorMessage(e, "Darslarni yuklab bo'lmadi"));
      } finally {
        setLoadingLessons(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [groupId]);

  useEffect(() => {
    if (!lessonId) return;
    (async () => {
      setLoadingGrades(true);
      try {
        const res = await gradeApi.getByLesson(lessonId);
        const list: Grade[] = res.data ?? [];
        const next: Record<string, { score: string; comment: string; gradeId?: string }> = {};
        for (const s of students) {
          const existing = list.find((g) => {
            const sid = typeof g.student_id === 'string' ? g.student_id : g.student_id?._id;
            return sid === s._id;
          });
          next[s._id] = { score: existing ? String(existing.score) : '', comment: existing?.comment ?? '', gradeId: existing?._id };
        }
        setRows(next);
      } catch (e) {
        showToast('error', errorMessage(e, "Baholarni yuklab bo'lmadi"));
      } finally {
        setLoadingGrades(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lessonId, students]);

  async function handleSaveRow(studentId: string) {
    const row = rows[studentId];
    if (!row || row.score === '') {
      showToast('error', 'Baho kiriting (0-100)');
      return;
    }
    const scoreNum = Number(row.score);
    if (Number.isNaN(scoreNum) || scoreNum < 0 || scoreNum > 100) {
      showToast('error', "Baho 0 dan 100 gacha bo'lishi kerak");
      return;
    }
    setSavingId(studentId);
    try {
      if (row.gradeId) {
        const res = await gradeApi.update(row.gradeId, { score: scoreNum, comment: row.comment || undefined });
        if (!res.success) {
          showToast('error', res.message || 'Xatolik');
          return;
        }
      } else {
        const dto: GradePayload = { student_id: studentId, lesson_id: lessonId, score: scoreNum, comment: row.comment || undefined };
        const res = await gradeApi.create(dto);
        if (!res.success) {
          showToast('error', res.message || 'Xatolik');
          return;
        }
        if (res.data) setRows((prev) => ({ ...prev, [studentId]: { ...prev[studentId], gradeId: res.data!._id } }));
      }
      showToast('success', 'Baho saqlandi');
    } catch (e) {
      showToast('error', errorMessage(e, "Saqlab bo'lmadi"));
    } finally {
      setSavingId(null);
    }
  }

  if (loadingLessons) return <p className="text-slate-400">Yuklanmoqda...</p>;
  if (lessons.length === 0) return <p className="text-slate-400">Avval "Darslar" bo'limidan dars qo'shing.</p>;
  if (students.length === 0) return <p className="text-slate-400">Bu guruhda hali o'quvchilar yo'q.</p>;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <label className="text-sm font-medium text-slate-600">Dars:</label>
        <select className={`${inputClass} max-w-sm`} value={lessonId} onChange={(e) => setLessonId(e.target.value)}>
          {lessons.map((l) => (
            <option key={l._id} value={l._id}>
              {l.name}
            </option>
          ))}
        </select>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-sm">
        <table className="w-full min-w-[560px] text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-3">O'quvchi</th>
              <th className="px-4 py-3">Ball (0-100)</th>
              <th className="px-4 py-3">Izoh</th>
              <th className="px-4 py-3 text-right">Amallar</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {loadingGrades && (
              <tr>
                <td colSpan={4} className="px-4 py-6 text-center text-slate-400">
                  Yuklanmoqda...
                </td>
              </tr>
            )}
            {!loadingGrades &&
              students.map((s) => (
                <tr key={s._id} className="hover:bg-slate-50/60">
                  <td className="px-4 py-3 font-medium text-slate-800">
                    {s.first_name} {s.last_name}
                  </td>
                  <td className="px-4 py-3">
                    <input
                      type="number"
                      min={0}
                      max={100}
                      className={`${inputClass} w-24`}
                      value={rows[s._id]?.score ?? ''}
                      onChange={(e) => setRows((prev) => ({ ...prev, [s._id]: { ...prev[s._id], score: e.target.value } }))}
                    />
                  </td>
                  <td className="px-4 py-3">
                    <input
                      className={inputClass}
                      placeholder="Ixtiyoriy"
                      value={rows[s._id]?.comment ?? ''}
                      onChange={(e) => setRows((prev) => ({ ...prev, [s._id]: { ...prev[s._id], comment: e.target.value } }))}
                    />
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button className={buttonPrimary} disabled={savingId === s._id} onClick={() => handleSaveRow(s._id)}>
                      {savingId === s._id ? 'Saqlanmoqda...' : 'Saqlash'}
                    </button>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ---------------- Davomat ----------------

function AttendanceTab({ groupId, students }: { groupId: string; students: User[] }) {
  const { showToast } = useToast();
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [lessonId, setLessonId] = useState('');
  const [loadingLessons, setLoadingLessons] = useState(true);
  const [loadingAttendance, setLoadingAttendance] = useState(false);
  const [statuses, setStatuses] = useState<Record<string, AttendanceStatusEnum>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      setLoadingLessons(true);
      try {
        const res = await lessonsApi.getByGroup(groupId);
        const list = res.data ?? [];
        setLessons(list);
        if (list.length > 0) setLessonId(list[0]._id);
      } catch (e) {
        showToast('error', errorMessage(e, "Darslarni yuklab bo'lmadi"));
      } finally {
        setLoadingLessons(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [groupId]);

  useEffect(() => {
    if (!lessonId) return;
    (async () => {
      setLoadingAttendance(true);
      try {
        const res = await attendanceApi.getByLesson(lessonId);
        const list: Attendance[] = res.data ?? [];
        const next: Record<string, AttendanceStatusEnum> = {};
        for (const s of students) {
          const existing = list.find((a) => {
            const sid = typeof a.student_id === 'string' ? a.student_id : a.student_id?._id;
            return sid === s._id;
          });
          next[s._id] = existing?.status ?? AttendanceStatusEnum.Kelmadi;
        }
        setStatuses(next);
      } catch (e) {
        showToast('error', errorMessage(e, "Davomatni yuklab bo'lmadi"));
      } finally {
        setLoadingAttendance(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lessonId, students]);

  async function handleSaveAll() {
    if (!lessonId || students.length === 0) return;
    setSaving(true);
    try {
      const dto: BulkAttendancePayload = {
        lesson_id: lessonId,
        records: students.map((s) => ({ student_id: s._id, status: statuses[s._id] ?? AttendanceStatusEnum.Kelmadi })),
      };
      const res = await attendanceApi.bulkMark(dto);
      if (!res.success) {
        showToast('error', res.message || 'Xatolik');
        return;
      }
      showToast('success', 'Davomat saqlandi');
    } catch (e) {
      showToast('error', errorMessage(e, "Saqlab bo'lmadi"));
    } finally {
      setSaving(false);
    }
  }

  if (loadingLessons) return <p className="text-slate-400">Yuklanmoqda...</p>;
  if (lessons.length === 0) return <p className="text-slate-400">Avval "Darslar" bo'limidan dars qo'shing.</p>;
  if (students.length === 0) return <p className="text-slate-400">Bu guruhda hali o'quvchilar yo'q.</p>;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <label className="text-sm font-medium text-slate-600">Dars:</label>
          <select className={`${inputClass} max-w-sm`} value={lessonId} onChange={(e) => setLessonId(e.target.value)}>
            {lessons.map((l) => (
              <option key={l._id} value={l._id}>
                {l.name}
              </option>
            ))}
          </select>
        </div>
        <button className={buttonPrimary} disabled={saving || loadingAttendance} onClick={handleSaveAll}>
          {saving ? 'Saqlanmoqda...' : "Hammasini saqlash"}
        </button>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-sm">
        <table className="w-full min-w-[480px] text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-3">O'quvchi</th>
              <th className="px-4 py-3">Holat</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {loadingAttendance && (
              <tr>
                <td colSpan={2} className="px-4 py-6 text-center text-slate-400">
                  Yuklanmoqda...
                </td>
              </tr>
            )}
            {!loadingAttendance &&
              students.map((s) => (
                <tr key={s._id} className="hover:bg-slate-50/60">
                  <td className="px-4 py-3 font-medium text-slate-800">
                    {s.first_name} {s.last_name}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap gap-2">
                      {Object.values(AttendanceStatusEnum).map((st) => (
                        <button
                          key={st}
                          type="button"
                          onClick={() => setStatuses((prev) => ({ ...prev, [s._id]: st }))}
                          className={`rounded-full border px-3 py-1 text-xs font-medium transition ${
                            statuses[s._id] === st
                              ? 'border-indigo-600 bg-indigo-600 text-white'
                              : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                          }`}
                        >
                          {ATTENDANCE_LABELS[st]}
                        </button>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
